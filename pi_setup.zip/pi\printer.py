import logging
import time

logger = logging.getLogger(__name__)

def print_job(job_id, filename, backend_api_url):
    """
    Dummy print function. In a real environment, this would:
    1. Download the file from backend_api_url/api/download/{job_id}
    2. Run 'lp -d PRINTER_NAME filename'
    """
    logger.info(f"============ PRINTING ============")
    logger.info(f"Job ID: {job_id}")
    logger.info(f"Filename: {filename}")
    logger.info(f"Printer spinning up...")
    time.sleep(3)
    logger.info(f"Pages printed successfully!")
    logger.info(f"==================================")
